This is a Wordle game created using JavaFX by Karan Bhagat for CSCE 314 with Prof. Lupoli
Link to demonstration video:
https://youtu.be/JRoTVuK-NvQ
*video was sped up to 1.3x speed in order to fit under 3 minutes, can be slowed down in YouTube if needed*